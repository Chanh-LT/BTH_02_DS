/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ou.quizapp_mssv.model;

import com.ou.quizapp_mssv.model.Choice;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author admin
 */
public class Question implements Cloneable {

    private int id;
    private String content;
    private String hint;
    private String level;
    private String category;
    private String image;
    private List<Choice> choices;

    @Override
    protected Object clone() {
        try {
            Question copy = (Question) super.clone();
            copy.choices = new ArrayList<>(this.choices);
            return copy;
        } catch (CloneNotSupportedException ex) {
            Logger.getLogger(Question.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public Question(int id, String content, String hint, String level, String category, String image, List<Choice> choices) {
        this.id = id;
        this.content = content;
        this.hint = hint;
        this.level = level;
        this.category = category;
        this.image = image;
        this.choices = choices;
    }    

    public Question(String content, String hint, String level, String category, String image, List<Choice> choices) {
        this.content = content;
        this.hint = hint;
        this.level = level;
        this.category = category;
        this.image = image;
        this.choices = choices;
    }    
    
    private Question(Builder builder){
        this.id = builder.id;
        this.content = builder.content;
        this.hint = builder.hint;
        this.level = builder.level;
        this.category = builder.category;
        this.image = builder.image;
        this.choices = builder.choices;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getHint() {
        return hint;
    }

    public void setHint(String hint) {
        this.hint = hint;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }    

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public List<Choice> getChoices() {
        return choices;
    }

    public void setChoices(List<Choice> choices) {
        this.choices = choices;
    }

    public static class Builder {

        private int id;
        private String content;
        private String hint;
        private String level;
        private String category;
        private String image;
        private List<Choice> choices;
        
        public Builder id(int id){
            this.id = id;
            return this;
        }
        
        public Builder content(String content){
            this.content = content;
            return this;
        }
        
        public Builder hint(String hint){
            this.hint = hint;
            return this;
        }
        
        public Builder level(String level_id){
            this.level = level_id;
            return this;
        }
        
        public Builder category(String categoryId){
            this.category = categoryId;
            return this;
        }
        
        public Builder choices(List<Choice> choices){
            this.choices = choices;
            return this;
        }
        
        public Question build(){
            return new Question(this);
        }
    }

}
