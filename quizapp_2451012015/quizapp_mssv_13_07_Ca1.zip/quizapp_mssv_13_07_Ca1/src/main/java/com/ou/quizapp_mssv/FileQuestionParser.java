/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ou.quizapp_mssv;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ou.quizapp_mssv.model.Catetegory;
import com.ou.quizapp_mssv.model.Choice;
import com.ou.quizapp_mssv.model.JsonChoiceDTO;
import com.ou.quizapp_mssv.model.JsonQuestionDTO;
import com.ou.quizapp_mssv.model.Question;
import com.ou.quizapp_mssv.model.Level;
import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class FileQuestionParser {
    
    private String path;
    
    public FileQuestionParser(String path) {
        this.path = path;
    }   
    
    public List<Question> parse(Catetegory c, Level lv) throws IOException{
        
        if(c == null)
            throw new IllegalArgumentException("Danh mục không được chọn");
        
        if(lv == null)
            throw new IllegalArgumentException("Độ khó không được chọn");
        
        Path jsonPath = Path.of(this.path);
        
        if(!Files.exists(jsonPath)){
            throw new IOException("Không tìm thấy file Json: " + path);
        }
        
        Gson gson = new Gson();
        Type typeOfT = new TypeToken<List<JsonQuestionDTO>>(){}.getType();
        
        try(Reader reader = Files.newBufferedReader(jsonPath, StandardCharsets.UTF_8)){
            List<JsonQuestionDTO> jsonQuestionDTO;            
            jsonQuestionDTO = gson.fromJson(reader, typeOfT);
            
            List<Question> questions = new ArrayList<>();
            
            for (int i = 0; i < jsonQuestionDTO.size(); i++) {
                JsonQuestionDTO dto = jsonQuestionDTO.get(i);
                
                List<Choice> choices = new ArrayList<>();
                for (JsonChoiceDTO choice : dto.getChoices()) {
                    choices.add(new Choice(choice.getContent().trim(), choice.isCorrect()));
                }
                
                Question question = new Question.Builder()
                        .content(dto.getContent())
                        .hint(dto.getHint())
                        .category(c.getName())
                        .level(lv.getName())
                        .choices(choices)
                        .build();
                questions.add(question);            
            }            
            return questions;
        }
    }
}
