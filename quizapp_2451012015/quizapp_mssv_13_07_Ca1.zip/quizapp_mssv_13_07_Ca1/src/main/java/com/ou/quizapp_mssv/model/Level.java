/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ou.quizapp_mssv.model;

/**
 *
 * @author admin
 */
public class Level {
    private int Id;
    private String name;
    private String note;

    public Level(String name) {
        this.name = name;
    }       

    public Level(int Id, String name, String note) {
        this.Id = Id;
        this.name = name;
        this.note = note;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
