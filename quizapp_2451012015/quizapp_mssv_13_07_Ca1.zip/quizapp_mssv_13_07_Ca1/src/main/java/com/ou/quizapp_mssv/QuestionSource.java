/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.ou.quizapp_mssv;

import com.ou.quizapp_mssv.model.Question;
import java.util.List;

/**
 *
 * @author admin
 */
public interface QuestionSource {
    List<Question> loadQuestions();
}
