/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ou.quizapp_mssv;

import com.ou.quizapp_mssv.model.Question;
import java.util.List;

/**
 *
 * @author admin
 */
public class QuestionUpdateService {
    
    QuestionRepository repository = new QuestionRepository();
    
    public boolean addQuestion(List<Question> questions){
        return  repository.addQuestion(questions);
    }
}
