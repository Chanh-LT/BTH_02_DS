/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ou.quizapp_mssv;

import com.ou.quizapp_mssv.model.Catetegory;
import com.ou.quizapp_mssv.model.Level;
import com.ou.quizapp_mssv.model.Question;
import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

/**
 *
 * @author admin
 */
public class FileQuestionAdapter implements QuestionSource {

    private FileQuestionParser adaptee;
    private Catetegory category;
    private Level level;

    public FileQuestionAdapter(FileQuestionParser adaptee, Catetegory category, Level level) {
        this.adaptee = adaptee;
        this.category = category;
        this.level = level;
    }  
    
    @Override
    public List<Question> loadQuestions(){
        try {
            return adaptee.parse(category, level);
        } catch (IOException ex) {
            Logger.getLogger(FileQuestionAdapter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        return null;
    }
    
    
}
