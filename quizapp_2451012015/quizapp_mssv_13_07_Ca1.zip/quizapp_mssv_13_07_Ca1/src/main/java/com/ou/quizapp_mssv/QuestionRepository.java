/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ou.quizapp_mssv;

import com.ou.quizapp_mssv.model.Question;
import com.ou.quizapp_mssv.model.Choice;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author admin
 */
public class QuestionRepository {
    
    public boolean addQuestion(List<Question> questions){        
        for (Question question : questions) {
           boolean result = addQuestionToDB(question);
           
           if(!result)
               MyAlert.getInstance().showMessage("Thêm câu hỏi không thành công");
        }
        return true;
    }
    
    public boolean addQuestionToDB(Question question) {
        
        try {
            Connection conn = JdbcConnector.getInstance().connect();
            
            String sqlQuestion = "INSERT INTO question(content, hint, image, category_id, level_id) "
                    + "VALUES (?,?,?,?,?)";
            
            PreparedStatement stmt = conn.prepareStatement(sqlQuestion, Statement.RETURN_GENERATED_KEYS);
            
            int category_id = getCategoryId(question.getCategory());
            int level_id = getLevel_Id(question.getLevel());
            
            stmt.setString(1, question.getContent());
            stmt.setString(2, question.getHint());
            stmt.setString(3, question.getImage());
            stmt.setInt(4, category_id);
            stmt.setInt(5, level_id);
            
            stmt.executeUpdate();
            
            ResultSet rs = stmt.getGeneratedKeys();
            int questionId = -1;
            if (rs.next()) {
                questionId = rs.getInt(1);
            }
            
            if (questionId == -1) {
                return false;
            }
            
            for (Choice choice : question.getChoices()) {
                choice.setQuestion_id(questionId);
                insertChoice(conn, choice);
            }            
            
            stmt.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Quizapp_mssv.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    private void insertChoice(Connection conn, Choice choice) {
        String sqlChoice = "INSERT INTO choice(content, is_correct, question_id)"
                + "VALUES(?,?,?)";
        
        try {
            PreparedStatement stmt = conn.prepareStatement(sqlChoice);
            stmt.setString(1, choice.getContent());
            stmt.setBoolean(2, choice.isCorrect());
            stmt.setInt(3, choice.getQuestion_id());
        } catch (SQLException ex) {
            Logger.getLogger(Quizapp_mssv.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private Integer getCategoryId(String value) {
        if(value == null || value.equals("Tất cả"))
            return null;
        
        return switch (value) {
            case "Grammar" ->
                1;
            case "Vocabulary" ->
                2;
            case "Reading" ->
                3;
            default ->
                null;
        };
    }
    
    private Integer getLevel_Id(String value) {
        if(value == null || value.equals("Tất cả"))
            return null;        
        
        return switch (value) {
            case "Easy" ->
                1;
            case "Medium" ->
                2;
            case "Hard" ->
                3;
            default ->
                1;
        };
    }
    
    public List<Question> getQuestionByFilter(String keyword, Integer category_id, Integer level_id, int limit){
        List<Question> questions = new ArrayList<>();
        try (Connection connection = JdbcConnector.getInstance().connect()) {            
            
            QuestionQueryBuilder queryBuilder = new QuestionQueryBuilder()
                    .categoryId(category_id)
                    .keyword(keyword)
                    .limit(limit)
                    .levelId(level_id);
            
            try (PreparedStatement stmt = connection.prepareStatement(queryBuilder.build())) {
                int idx = 1;
                for (Object param : queryBuilder.getParams()) {
                    stmt.setObject(idx, param);
                    idx++;
                }
                
                ResultSet rs = stmt.executeQuery();
                List<Question> tmp = new ArrayList<>();
                int questionId = -1;
                while (rs.next()) {
                    questionId = rs.getInt("id");
                    Question q = new Question(questionId, rs.getString("content"),
                            rs.getString("hint"), rs.getString("level"), rs.getString("category"), "", null);
                    
                    tmp.add(q);
                }
                
                for (Question q : tmp) {
                    q.setChoices(getChoices(questionId));
                    questions.add(q);
                }
                
                rs.close();
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(QuestionRepository.class.getName()).log(Level.SEVERE, null, ex);
            ex.printStackTrace();
        }
        return questions;
    }

    private List<Choice> getChoices(int questionId) {
        List<Choice> choices = new ArrayList<>();
        
        try(Connection conn = JdbcConnector.getInstance().connect(); PreparedStatement stmt = conn.prepareStatement("SELECT id, content, is_correct "
                + " FROM choice WHERE question_id = ?")){
            
            stmt.setInt(1, questionId);
            
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {                
                Choice choice = new Choice(rs.getInt("id"), rs.getString("content"),
                        rs.getInt("is_correct") == 1 );
                choices.add(choice);
            }
            
            rs.close();
            
            
        } catch (SQLException ex) {
            Logger.getLogger(QuestionRepository.class.getName()).log(Level.SEVERE, null, ex);
        }        
        
        return choices;
    }
}
